﻿Imports System.Data.OleDb
Imports System.Linq.Expressions
Public Class Form1
    Dim connString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\user\Documents\Access.Database.accdb"
    Dim connection As New OleDbConnection(connString)
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            connection.Open()
            Dim sql As String = "INSERT INTO africa_database (ID, Name, Age, Gender, Address) VALUES (@ID, @Name, @Age, @Gender, @Address)"
            Dim command As New OleDbCommand(sql, connection)

            command.Parameters.AddWithValue("@ID", txtID.Text)

            command.Parameters.AddWithValue("@Name", txtName.Text)

            command.Parameters.AddWithValue("@Age", txtAge.Text)

            command.Parameters.AddWithValue("@Gender", txtGender.Text)

            command.Parameters.AddWithValue("@Address", txtAddress.Text)
            command.ExecuteNonQuery()
            MessageBox.Show("Record added successfully!")
        Catch ex As Exception
            MessageBox.Show("Error adding record:" & ex.Message)
        Finally
            connection.Close()
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            connection.Open()
            Dim sql As String = "DELETE FROM africa_database WHERE ID = @ID"
            Dim command As New OleDbCommand(sql, connection)
            command.Parameters.AddWithValue("@ID", txtID.Text)
            command.ExecuteNonQuery()
            MessageBox.Show("Record deleted successfully!")
        Catch ex As Exception
            MessageBox.Show("Error deleting record: & ex.Message")
        Finally
            connection.Close()

        End Try
    End Sub
End Class
